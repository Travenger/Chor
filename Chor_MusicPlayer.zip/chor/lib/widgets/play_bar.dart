import 'package:chor/bloc/player_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cached_network_image/cached_network_image.dart';

class PlayBar extends StatelessWidget {
  const PlayBar({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PlayerBloc, PlayerState>(
      builder: (context, state) {
        // Only show PlayBar when there's a song loaded (Playing or Paused)
        if (state is PlayerInitial || state.song == null) {
          return const SizedBox.shrink();
        }

        bool isPlaying = state is PlayerPlaying;

        return Container(
          height: 80,
          decoration: BoxDecoration(
            color: const Color(0x801B1A55),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(16),
              topRight: Radius.circular(16),
            ),
          ),
          child: Row(
            children: [
              // Album Art
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: CachedNetworkImage(
                      imageUrl: state.coverImageUrl ??
                          "https://via.placeholder.com/50",
                      fit: BoxFit.cover,
                      placeholder: (context, url) => const Center(
                        child: CircularProgressIndicator(),
                      ),
                      errorWidget: (context, url, error) => Container(
                        color: Colors.grey[300],
                        child: const Icon(Icons.music_note),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              // Song Details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      state.song ?? "Unknown Song",
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      state.artist ?? "Unknown Artist",
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              // Like Button
              IconButton(
                icon: Icon(
                  state.isLiked
                      ? Icons.thumb_up_alt_rounded
                      : Icons.thumb_up_alt,
                  color: Color(0xFFEEEEEE),
                ),
                onPressed: () {
                  context.read<PlayerBloc>().add(ToggleLike());
                },
              ),
              // Play/Pause Button
              IconButton(
                icon: Icon(
                  isPlaying
                      ? Icons.pause_circle_filled
                      : Icons.play_circle_filled,
                  size: 40,
                  color: Colors.white,
                ),
                onPressed: () {
                  if (isPlaying) {
                    context.read<PlayerBloc>().add(PauseSong());
                  } else {
                    context.read<PlayerBloc>().add(
                          PlaySong(
                            song: state.song ?? "",
                            artist: state.artist ?? "",
                            coverImageUrl: state.coverImageUrl ?? "",
                            songUrl: state.songUrl ?? "",
                          ),
                        );
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
