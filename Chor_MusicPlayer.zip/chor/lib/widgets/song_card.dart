import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:chor/bloc/player_bloc.dart';

class SongCard extends StatelessWidget {
  final String coverImageUrl;
  final String songUrl;
  final String title;
  final String artist;
  final bool isUploadedByUser;
  final VoidCallback? onEdit;
  final VoidCallback? onTap;

  const SongCard({
    super.key,
    required this.coverImageUrl,
    required this.songUrl,
    required this.title,
    required this.artist,
    this.isUploadedByUser = true,
    this.onEdit,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        try {
          context.read<PlayerBloc>().add(
                PlaySong(
                  song: title,
                  artist: artist,
                  coverImageUrl: coverImageUrl,
                  songUrl: songUrl,
                ),
              );

          // Also call the original onTap if provided
          onTap?.call();
        } catch (e) {
          print('Error playing song: $e'); // For debugging
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error playing song: $e')),
          );
        }
      },
      borderRadius: BorderRadius.circular(8),
      // Rest of your existing SongCard implementation...
      child: Container(
        height: 70,
        decoration: BoxDecoration(
          color: const Color(0x801B1A55),
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                coverImageUrl,
                width: 70,
                height: 70,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  color: const Color(0xFFEEEEEE),
                  width: 70,
                  height: 70,
                  child: const Icon(
                    Icons.image_not_supported,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12),
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFEEEEEE),
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    artist,
                    style: const TextStyle(
                      fontSize: 14,
                      color: Color(0xCCEEEEEE),
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (isUploadedByUser)
              IconButton(
                icon: const Icon(
                  Icons.edit,
                  color: Colors.grey,
                ),
                onPressed: () {
                  _showEditSongDialog(context, title, artist);
                },
                tooltip: 'Edit song',
              ),
          ],
        ),
      ),
    );
  }
}

void _showEditSongDialog(
    BuildContext context, String currentTitle, String currentArtist) {
  showDialog(
    context: context,
    builder: (context) {
      return Dialog(
        backgroundColor: const Color(0x991B1A55),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.8, // Custom width
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Edit Song",
                style: const TextStyle(
                  color: Color(0xFFEEEEEE),
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title
                  const Text(
                    "Title",
                    style: TextStyle(
                      color: Color(0xFFEEEEEE),
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: TextEditingController(text: currentTitle),
                    decoration: InputDecoration(
                      hintText: "Enter title",
                      filled: true,
                      fillColor: const Color(0xFFEEEEEE),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      hintStyle: const TextStyle(
                        color: Color(0xFF282828),
                        fontSize: 14,
                      ),
                    ),
                    style: const TextStyle(color: Color(0xFF282828)),
                  ),
                  const SizedBox(height: 16),
                  // Artist
                  const Text(
                    "Artist (comma separated)",
                    style: TextStyle(
                      color: Color(0xFFEEEEEE),
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: TextEditingController(text: currentArtist),
                    decoration: InputDecoration(
                      hintText: "Enter artist name",
                      filled: true,
                      fillColor: const Color(0xFFEEEEEE),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      hintStyle: const TextStyle(
                        color: Color(0xFF282828),
                        fontSize: 14,
                      ),
                    ),
                    style: const TextStyle(color: Color(0xFF282828)),
                  ),
                  const SizedBox(height: 16),
                  // Song File
                  const Text(
                    "Song File",
                    style: TextStyle(
                      color: Color(0xFFEEEEEE),
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    onPressed: () {
                      // Handle file selection
                    },
                    icon:
                        const Icon(Icons.upload_file, color: Color(0xFFEEEEEE)),
                    label: const Text(
                      "Choose File",
                      style: TextStyle(color: Color(0xFFEEEEEE)),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1B1A55),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Song Cover File
                  const Text(
                    "Song Cover File",
                    style: TextStyle(
                      color: Color(0xFFEEEEEE),
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    onPressed: () {
                      // Handle image selection
                    },
                    icon: const Icon(Icons.image, color: Color(0xFFEEEEEE)),
                    label: const Text(
                      "Choose File",
                      style: TextStyle(color: Color(0xFFEEEEEE)),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1B1A55),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Action Buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text(
                          "Cancel",
                          style: TextStyle(color: Color(0xFFEEEEEE)),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          // Handle song update logic
                          Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1B1A55),
                        ),
                        child: const Text(
                          "Save",
                          style: TextStyle(color: Color(0xFFEEEEEE)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    },
  );
}
