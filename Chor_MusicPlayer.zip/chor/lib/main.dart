import 'package:chor/bloc/player_bloc.dart';
import 'package:chor/pages/auth/signin_or_signup.dart';
import 'package:chor/pages/home_page.dart';
import 'package:chor/pages/library_page.dart';
import 'package:chor/pages/search_page.dart';
import 'package:chor/services/firebase_auth.dart';
import 'package:chor/widgets/nav_bar.dart';
import 'package:chor/widgets/play_bar.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    ChangeNotifierProvider(
      create: (_) => AuthService(),
      child: BlocProvider(create: (_) => PlayerBloc(), child: const MyApp()),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _selectedIndex = 0;
  final List<Widget> _pages = [
    HomePage(),
    SearchPage(),
    LibraryPage(),
  ];

  void _onNavBarTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context);
    final bool isAuthenticated = authService.user != null;

    return MaterialApp(
      title: 'Chor',
      debugShowCheckedModeBanner: false,
      home: isAuthenticated
          ? Scaffold(
              body: Stack(
                children: [
                  // Main content
                  _pages[_selectedIndex],

                  // PlayBar positioned at bottom
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0, // Height of BottomNavigationBar
                    child: const PlayBar(),
                  ),
                ],
              ),
              bottomNavigationBar: BottomNavBar(
                selectedIndex: _selectedIndex,
                onTap: _onNavBarTap,
              ),
            )
          : const SignInOrSignUp(),
    );
  }
}

// import 'package:chor/bloc/player_bloc.dart';
// import 'package:chor/pages/auth/signin_or_signup.dart';
// import 'package:chor/pages/home_page.dart';
// import 'package:chor/pages/library_page.dart';
// import 'package:chor/pages/search_page.dart';
// import 'package:chor/services/firebase_auth.dart';
// import 'package:chor/widgets/nav_bar.dart';
// import 'package:flutter/material.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:provider/provider.dart';

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp();
//   runApp(
//     ChangeNotifierProvider(
//       create: (_) => AuthService(),
//       child: BlocProvider(create: (_) => PlayerBloc(), child: const MyApp()),
//     ),
//   );
// }

// class MyApp extends StatefulWidget {
//   const MyApp({super.key});

//   @override
//   State<MyApp> createState() => _MyAppState();
// }

// class _MyAppState extends State<MyApp> {
//   int _selectedIndex = 0;

//   // List of pages for the main app with navigation
//   final List<Widget> _pages = [
//     HomePage(),
//     SearchPage(),
//     LibraryPage(),
//   ];

//   // Function to handle navigation
//   void _onNavBarTap(int index) {
//     setState(() {
//       _selectedIndex = index;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     final authService = Provider.of<AuthService>(context);

//     // Determine the initial screen based on user authentication state
//     final bool isAuthenticated = authService.user != null;

//     // App content
//     return MaterialApp(
//       title: 'Chor',
//       debugShowCheckedModeBanner: false,
//       home: isAuthenticated
//           ? Scaffold(
//               body: _pages[_selectedIndex],
//               bottomNavigationBar: BottomNavBar(
//                 selectedIndex: _selectedIndex,
//                 onTap: _onNavBarTap,
//               ),
//             )
//           : const SignInOrSignUp(),
//     );
//   }
// }
